#include <bits/stdc++.h>
using namespace std;

class Solution {
public:
    // Monotonic Stack Approach
    // Time Complexity: O(n) - each temperature is pushed and popped at most once
    // Space Complexity: O(n) - stack and result array
    vector<int> dailyTemperatures(vector<int>& temperatures) {
        int n = temperatures.size();
        vector<int> res(n, 0); // Result array initialized with zeros
        stack<int> st; // Stack stores indices of temperatures
        
        for (int i = 0; i < n; ++i) {
            // While current temperature is greater than the temperature at the top of the stack
            while (!st.empty() && temperatures[i] > temperatures[st.top()]) {
                int prevIndex = st.top();
                st.pop();
                res[prevIndex] = i - prevIndex; // Calculate days until warmer temperature
            }
            st.push(i); // Push current index to stack
        }
        return res;
    }
};

/*
Line-by-line C++ syntax explanation for beginners:

#include <bits/stdc++.h>         // Includes all standard C++ libraries (for competitive programming)
using namespace std;             // Allows us to use standard library names without 'std::' prefix

class Solution {                 // Defines a class named Solution
public:                          // Public access specifier (methods accessible from outside)
    vector<int> dailyTemperatures(vector<int>& temperatures) {
        int n = temperatures.size();           // Get the number of temperatures
        vector<int> res(n, 0);                // Create a result vector of size n, initialized to 0
        stack<int> st;                        // Create a stack to store indices
        
        for (int i = 0; i < n; ++i) {         // Loop through each temperature
            while (!st.empty() && temperatures[i] > temperatures[st.top()]) {
                int prevIndex = st.top();      // Get the index from the top of the stack
                st.pop();                      // Remove the top index from the stack
                res[prevIndex] = i - prevIndex; // Store the number of days until a warmer temperature
            }
            st.push(i);                       // Push the current index onto the stack
        }
        return res;                           // Return the result vector
    }
};
*/
